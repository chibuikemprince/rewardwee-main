"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionPlanController = void 0;
const external_1 = require("../databases/external");
const types_1 = require("../modules/types");
const errorReporting_1 = require("../helpers/errorReporting");
class SubscriptionPlanModule {
    constructor() {
    }
    /**
     * This method is used to create a new subscription plan.
     * It checks if all required fields are present and not null. If the plan data is valid,
     * it creates a new subscription plan in the database and returns a success message.
     * If there's an error during the process, it logs the error and returns an error message.
     *
     * @param plan
     *
     * @returns
     */
    createPlan(plan) {
        return new Promise((resolve, reject) => {
            try {
                // check that plan data contains all required fields in SubscriptionPlanType and non is null
                if (plan.name
                    && plan.name.length
                    && plan.adminId
                    && plan.duration
                    && plan.duration > 0
                    && plan.price
                    && plan.currency
                    && types_1.CurrencyArray.indexOf(plan.currency) >= 0) {
                    if (plan.hasOwnProperty("name") && plan.name) {
                        plan.name = plan.name.toLowerCase();
                    }
                    // name should be unique
                    external_1.AllSubscriptionPlans.findOne({ name: plan.name })
                        .then((foundPlan) => {
                        if (foundPlan == null) {
                            external_1.AllSubscriptionPlans.create(plan)
                                .then((createdPlan) => {
                                let res = {
                                    status: 200,
                                    message: "Plan created successfully",
                                    data: [],
                                    statusCode: "PLAN_CREATED"
                                };
                                resolve(res);
                                return;
                            })
                                .catch((err) => {
                                let error_log = {
                                    msg: `Error occurred. Error: ${err.message}`,
                                    status: "MILD",
                                    time: new Date().toUTCString(),
                                    stack: err.stack,
                                    class: this
                                };
                                (0, errorReporting_1.LogError)(error_log);
                                let response_error = {
                                    status: 500,
                                    message: "unknown error occurred",
                                    data: [],
                                    statusCode: "UNKNOWN_ERROR"
                                };
                                reject(response_error);
                                return;
                            });
                        }
                        else {
                            let response_error = {
                                data: [],
                                message: "Plan name already exists",
                                status: 409,
                                statusCode: "PLAN_NAME_EXISTS"
                            };
                            reject(response_error);
                            return;
                        }
                    })
                        .catch((err) => {
                        let error = {
                            msg: `Error occurred. Error: ${err.message}`,
                            status: "STRONG",
                            time: new Date().toUTCString(),
                            stack: err.stack,
                            class: this
                        };
                        (0, errorReporting_1.LogError)(error);
                        let response_error = {
                            data: [],
                            message: "unknown error occurred",
                            status: 500,
                            statusCode: "UNKNOWN_ERROR"
                        };
                        reject(response_error);
                        return;
                    });
                }
                else {
                    let response_error = {
                        data: [],
                        message: "Please enter all required fields",
                        status: 400,
                        statusCode: "FORM_REQUIREMENT_ERROR"
                    };
                    reject(response_error);
                    return;
                }
            }
            catch (err) {
                let error = {
                    msg: `Error occurred. Error: ${err.message}`,
                    status: "STRONG",
                    time: new Date().toUTCString(),
                    stack: err.stack,
                    class: this
                };
                (0, errorReporting_1.LogError)(error);
                let response_error = {
                    data: [],
                    message: "unknown error occurred",
                    status: 500,
                    statusCode: "UNKNOWN_ERROR"
                };
                reject(response_error);
                return;
            }
        });
    }
    /**
     * This method is used to retrieve all subscription plans from the database.
     * If there are no plans in the database, it returns a "plans not found" message.
     * If there's an error during the process, it logs the error and returns an error message.
     * @returns
     */
    viewAllPlans(isAdmin = false) {
        return new Promise((resolve, reject) => {
            let returnAdminId = 0;
            if (isAdmin) {
                returnAdminId = 1;
            }
            external_1.AllSubscriptionPlans.find({}, { adminId: returnAdminId })
                .then((plans) => {
                // check if plan is empty and return 404 error
                if (plans.length === 0) {
                    let res = {
                        status: 404,
                        message: "plans not found",
                        data: [],
                        statusCode: "PLANS_NOT_FOUND"
                    };
                    reject(res);
                    return;
                }
                else {
                    let res = {
                        status: 200,
                        message: "plans found successfully",
                        data: plans,
                        statusCode: "PLANS_FOUND"
                    };
                    resolve(res);
                    return;
                }
            })
                .catch((err) => {
                let error_log = {
                    msg: `Error occurred. Error: ${err.message}`,
                    status: "MILD",
                    time: new Date().toUTCString(),
                    stack: err.stack,
                    class: this
                };
                (0, errorReporting_1.LogError)(error_log);
                let response_error = {
                    status: 500,
                    message: "unknown error occurred, please try again",
                    data: [],
                    statusCode: "UNKNOWN_ERROR"
                };
                reject(response_error);
                return;
            });
        });
    }
    /**
     * This method is used to retrieve a specific subscription plan using the plan's ID.
     * If the plan is not found, it returns a "plan not found" message.
     * If there's an error during the process, it logs the error and returns an error message.
     *
     * @param planId - ObjectId of the plan to be viewed.
     * @returns
     */
    viewOnePlan(planId, isAdmin = false) {
        return new Promise((resolve, reject) => {
            let returnAdminId = 0;
            if (isAdmin) {
                returnAdminId = 1;
            }
            external_1.AllSubscriptionPlans.findOne({ _id: planId }, { adminId: returnAdminId })
                .then((plans) => {
                // check if plan is empty and return 404 error
                if (plans === null) {
                    let res = {
                        status: 404,
                        message: "plan not found",
                        data: [],
                        statusCode: "RESOURCE_NOT_FOUND"
                    };
                    reject(res);
                    return;
                }
                else {
                    let res = {
                        status: 200,
                        message: "plan data fetched successfully",
                        data: [plans],
                        statusCode: "SUCCESS"
                    };
                    resolve(res);
                    return;
                }
            })
                .catch((err) => {
                let error_log = {
                    msg: `Error occurred. Error: ${err.message}`,
                    status: "MILD",
                    time: new Date().toUTCString(),
                    stack: err.stack,
                    class: this
                };
                (0, errorReporting_1.LogError)(error_log);
                let response_error = {
                    status: 500,
                    message: "unknown error occurred, please try again",
                    data: [],
                    statusCode: "UNKNOWN_ERROR"
                };
                reject(response_error);
                return;
            });
        });
    }
    /**
     *  This method is used to update a specific subscription plan using the plan's ID and the new plan data.
     * If the plan is not found, it returns a "plan not found" message. If the plan is updated successfully,
     *  it returns a success message.
     * If there's an error during the process, it logs the error and returns an error message.
     * @param planId
     *
     * @param plan
     * @returns
     */
    // update a plan
    updatePlan(planId, plan) {
        return new Promise((resolve, reject) => {
            // if plan has name property, make it lowercase
            if (plan.hasOwnProperty("name") && plan.name) {
                plan.name = plan.name.toLowerCase();
            }
            external_1.AllSubscriptionPlans.findOneAndUpdate({ _id: planId }, plan)
                .then((plans) => {
                // check if plan is empty and return 404 error
                if (plans === null) {
                    let res = {
                        status: 404,
                        message: "plan not found",
                        data: [],
                        statusCode: "RESOURCE_NOT_FOUND"
                    };
                    reject(res);
                    return;
                }
                else {
                    let res = {
                        status: 200,
                        message: "plan updated successfully",
                        data: [],
                        statusCode: "SUCCESS"
                    };
                    resolve(res);
                    return;
                }
            })
                .catch((err) => {
                // handle mongoose duplicate error
                if (err.code === 11000) {
                    let response_error = {
                        status: 409,
                        message: "plan name must be unique, please enter a unique plan name",
                        data: [],
                        statusCode: "ALREADY_EXISTS"
                    };
                    reject(response_error);
                    return;
                }
                let error_log = {
                    msg: `Error occurred. Error: ${err.message}`,
                    status: "MILD",
                    time: new Date().toUTCString(),
                    stack: err.stack,
                    class: this
                };
                (0, errorReporting_1.LogError)(error_log);
                let response_error = {
                    status: 500,
                    message: "unknown error occurred, please try again",
                    data: [],
                    statusCode: "UNKNOWN_ERROR"
                };
                reject(response_error);
                return;
            });
        });
    }
}
exports.SubscriptionPlanController = new SubscriptionPlanModule();
