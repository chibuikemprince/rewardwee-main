"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const SubscriptionPlanMiddleware_1 = __importDefault(require("../middlewares/SubscriptionPlanMiddleware"));
const adminauth_1 = require("../middlewares/adminauth");
const pathRouter = (0, express_1.Router)();
const baseRouter = (0, express_1.Router)();
// Subscription 
pathRouter.get("/all", SubscriptionPlanMiddleware_1.default.getAllPlan);
pathRouter.get("/one", SubscriptionPlanMiddleware_1.default.getOnePlan);
pathRouter.post("/create", adminauth_1.isAdminTokenCorrect, SubscriptionPlanMiddleware_1.default.createPlan);
pathRouter.put("/update/", adminauth_1.isAdminTokenCorrect, SubscriptionPlanMiddleware_1.default.updatePlan);
// get all currency
pathRouter.get("/currency/all", SubscriptionPlanMiddleware_1.default.getAllCurrency);
exports.default = baseRouter.use("/plans", pathRouter);
