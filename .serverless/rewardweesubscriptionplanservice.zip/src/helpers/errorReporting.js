"use strict";
// import Logger from "logger";
// import pino from  'pino'
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogError = void 0;
const LogError = (err) => {
    //'fatal', 'error', 'warn', 'info', 'debug'
    let loggerOrder = 'warn';
    if (err.status == 'STRONG') {
        loggerOrder = 'fatal';
    }
    else if (err.status == 'INFO') {
        loggerOrder = 'info';
    }
    console.log(err);
    return;
};
exports.LogError = LogError;
