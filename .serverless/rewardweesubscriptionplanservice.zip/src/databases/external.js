"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AllSubscriptionPlans = exports.UserLoginRecord = void 0;
const mongoose_1 = require("mongoose");
const reward_service_store_schemas_1 = require("reward_service_store_schemas");
//import {LoginRecord, UserLoginRecordData}  from "../../../rewardwee_database/src/login"
exports.UserLoginRecord = (0, mongoose_1.model)(reward_service_store_schemas_1.UserLoginRecordModelData.name, reward_service_store_schemas_1.UserLoginRecordSchema);
exports.AllSubscriptionPlans = (0, mongoose_1.model)(reward_service_store_schemas_1.SubscriptionPlanDataModel.name, reward_service_store_schemas_1.SubscriptionPlanSchema);
