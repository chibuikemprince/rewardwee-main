"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isTokenCorrect = void 0;
const misc_1 = require("../helpers/misc");
const login_1 = require("../modules/login");
function extractTokenFromHeader(header) {
    if (header == undefined) {
        return undefined;
    }
    const parts = header.split(' ');
    if (parts.length === 3 && parts[0] === 'Bearer') {
        console.log({ part1: parts[1], part2: parts[2] });
        return [parts[1], parts[2]];
    }
    return undefined;
}
const isTokenCorrect = (req, res, next) => {
    const authHeader = req.headers.authorization;
    const tokenData = extractTokenFromHeader(authHeader);
    console.log({ authHeader, tokenData });
    if (tokenData != undefined) {
        let token = tokenData[0];
        // get token
        (0, misc_1.extractTokenContent)(token)
            .then((verified) => {
            console.log({ verified });
            let { id, email, time } = verified.data[0];
            let user_id = tokenData[1];
            console.log({ token, user_id });
            if (id != user_id) {
                let error = {
                    data: [],
                    message: "invalid login token.",
                    status: 400,
                    statusCode: "LOGIN_FAILED"
                };
                console.log({ error });
                (0, misc_1.response)(res, error);
                return;
            }
            login_1.authLogin.isUserLoggedIn(id, token)
                .then((success) => {
                if (success.statusCode == "LOGIN_SUCCESSFUL") {
                    req.user_id = id;
                    req.user_email = email;
                    req.user_token = token;
                    next();
                }
                else {
                    (0, misc_1.response)(res, success);
                    return;
                }
            })
                .catch((err) => {
                (0, misc_1.response)(res, err);
                return;
            });
        })
            .catch((err) => {
            console.log({ err });
            (0, misc_1.response)(res, err);
            return;
        });
    }
    else {
        let error = {
            data: [],
            message: "invalid login token.",
            status: 400,
            statusCode: "LOGIN_FAILED"
        };
        console.log({ error });
        (0, misc_1.response)(res, error);
        return;
    }
};
exports.isTokenCorrect = isTokenCorrect;
