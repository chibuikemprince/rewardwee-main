"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetSIngleSubscriptionPlan = exports.UpdateSubscriptionPlan = exports.CreateSubscriptionPlan = void 0;
const joi_1 = __importDefault(require("joi"));
/* import JoiPhoneNumber  from "joi-phone-number";

let phoneJoi = joi.extend(JoiPhoneNumber);

export const registerSchema = phoneJoi.object({
    firstName: phoneJoi.string().required(),
    lastName: phoneJoi.string().required(),
    email: phoneJoi.string().email().required(),
    phoneNumber: phoneJoi.string().phoneNumber().pattern(/^\+[0-9]{4,18}$/).required(),
    password: phoneJoi.string().min(6).max(50).required(),
    company: phoneJoi.string().required(),
    team: phoneJoi.string().required()
})
 */
exports.CreateSubscriptionPlan = joi_1.default.object({
    name: joi_1.default.string().required(),
    description: joi_1.default.array(),
    price: joi_1.default.number().required(),
    duration: joi_1.default.number().required(),
    currency: joi_1.default.string().required(),
    adminId: joi_1.default.string(),
    freeTrialDuration: joi_1.default.number()
});
exports.UpdateSubscriptionPlan = joi_1.default.object({
    name: joi_1.default.string(),
    description: joi_1.default.array(),
    price: joi_1.default.number(),
    duration: joi_1.default.number(),
    currency: joi_1.default.string(),
    freeTrialDuration: joi_1.default.number()
});
exports.GetSIngleSubscriptionPlan = joi_1.default.object({
    plan_id: joi_1.default.string().required(),
});
