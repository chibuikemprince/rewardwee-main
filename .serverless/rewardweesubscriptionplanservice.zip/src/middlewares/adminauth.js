"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isAdminTokenCorrect = void 0;
const misc_1 = require("../helpers/misc");
const isAdminTokenCorrect = (req, res, next) => {
    if (req.headers.authorization) {
        let token = req.headers.authorization.split(' ');
        req.user_id = token[2];
        next();
    }
    else {
        let err = {
            status: 401,
            message: "Unauthorized",
            data: [],
            statusCode: "UNKNOWN_ERROR"
        };
        (0, misc_1.response)(res, err);
        return;
    }
};
exports.isAdminTokenCorrect = isAdminTokenCorrect;
