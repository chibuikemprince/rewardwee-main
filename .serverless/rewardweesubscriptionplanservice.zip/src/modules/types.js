"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CurrencyArray = void 0;
const reward_service_store_schemas_1 = require("reward_service_store_schemas");
exports.CurrencyArray = reward_service_store_schemas_1.CurrencyArray;
console.log({ CurrencyArray: exports.CurrencyArray });
