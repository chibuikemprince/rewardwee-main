"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CurrencyArray = void 0;
const index_1 = require("../../../rewardwee_database/src/types/index");
exports.CurrencyArray = Object.values(index_1.Currency);
