"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authLogin = void 0;
const reward_service_global_auth_in_1 = require("reward_service_global_auth_in");
const external_1 = require("../databases/external");
exports.authLogin = new reward_service_global_auth_in_1.AuthLoginClass(external_1.UserLoginRecord);
