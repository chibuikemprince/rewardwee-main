"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getGlobalEnv = exports.getAllGlobalEnv = void 0;
const mongoose_1 = require("mongoose");
// globalenv module
/*
This code is a module that exports a function  `getGlobalEnv`  which takes a key as input and returns the corresponding value from the global environment.
 The code imports the necessary dependencies from external modules, including  `GlobalParams`  and  `Env_val`  from "reward_service_global_env", and  `GlobalEnvSchema`  and  `GlobalEnvModelData`  from "reward_service_store_schemas".
 It defines a model  `EnvParameter`  using  `GlobalEnvModelData`  and  `GlobalEnvSchema` .
 It creates an instance of  `GlobalParams`  by passing  `EnvParameter`  as a parameter.
 It initializes a variable  `myENV`  to null.
 The  `getEnv`  function is defined as an async function that returns a promise.
  It checks if  `myENV`  is null,
  and if so, retrieves the global environment
  from the database using  `GlobalParamsObject.getFromDB()` .
  It assigns the retrieved environment to  `myENV`
  and resolves the promise with the environment.
   If  `myENV`  is not null, it resolves the promise with  `myENV`  directly.
 The  `getGlobalEnv`  function is defined as a function that takes a key as input.
 It calls the  `getEnv`  function to retrieve the global environment,
 and then returns the corresponding value for the given key from the environment.
  If an error occurs during the retrieval of the environment,
  it returns the corresponding error for the given key.
*/
const reward_service_global_env_1 = require("reward_service_global_env");
const reward_service_store_schemas_1 = require("reward_service_store_schemas");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const env_1 = require("../../env");
const currentFolderPath = path_1.default.dirname(__filename);
// console.log(currentFolderPath);
const EnvParameter = (0, mongoose_1.model)(reward_service_store_schemas_1.GlobalEnvModelData.name, reward_service_store_schemas_1.GlobalEnvSchema);
let GlobalParamsObject = new reward_service_global_env_1.GlobalParams(EnvParameter);
let myENV = null;
const getAllGlobalEnv = function () {
    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
        let count = 0;
        if (myENV == null) {
            while (myENV == null) {
                console.log({ count });
                count = count + 1;
                let env = yield GlobalParamsObject.getFromDB();
                if (Object.values(env).length > 0) {
                    myENV = env;
                    fs_1.default.writeFile(currentFolderPath + '/globalenvdata.json', JSON.stringify(env), (err) => {
                        if (err) {
                            console.error('Error writing to file:', err);
                            return;
                        }
                        console.log('Data written to file successfully!');
                        resolve(myENV);
                    });
                }
                if (count > 20) {
                    process.exit();
                }
            }
        }
        else {
            console.log("Local ENV");
            resolve(myENV);
        }
    }));
};
exports.getAllGlobalEnv = getAllGlobalEnv;
const getGlobalEnv = function (key) {
    let val = env_1.globalENVData[key];
    //console.log({key, val})
    return val;
};
exports.getGlobalEnv = getGlobalEnv;
// getGlobalEnv("a")
