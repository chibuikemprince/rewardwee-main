"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserLoginRecord = exports.UserModel = void 0;
const mongoose_1 = require("mongoose");
const reward_service_store_schemas_1 = require("reward_service_store_schemas");
exports.UserModel = (0, mongoose_1.model)(reward_service_store_schemas_1.UserModelData.name, reward_service_store_schemas_1.UserModelSchema);
//import {LoginRecord, UserLoginRecordData}  from "../../../rewardwee_database/src/login"
exports.UserLoginRecord = (0, mongoose_1.model)(reward_service_store_schemas_1.UserLoginRecordModelData.name, reward_service_store_schemas_1.UserLoginRecordSchema);
console.log({ name1: reward_service_store_schemas_1.UserModelData.name, name2: reward_service_store_schemas_1.UserLoginRecordModelData.name });
