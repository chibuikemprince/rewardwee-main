"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EMAIL_TEMPLATES = void 0;
exports.EMAIL_TEMPLATES = {
    ACCOUNT_ACTIVATION: "ACCOUNT_ACTIVATION_ID"
};
