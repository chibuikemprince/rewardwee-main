"use strict";
//import sendgrid email library
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const controllers_1 = require("./src/controllers");
const errorReporting_1 = require("./src/helpers/errorReporting");
const handler = (event, context) => __awaiter(void 0, void 0, void 0, function* () {
    //to: string, subject: string, text: string, html?: string
    //console.log({event, context, function:"EMAIL"})
    let { to, subject, text, html, templateId, dynamicTemplateData, differentEmails, differentEmailTemplates } = event.detail.data;
    console.log({ detail: event.detail, function: "EMAIL" });
    let type = event.detail.type;
    let feedback;
    let error_log;
    switch (type) {
        case "single":
            try {
                feedback = yield controllers_1.SingleMailService.sendEmail(to, subject, text, html);
                console.log({ feedback, action: "single without template success" });
            }
            catch (err) {
                error_log = {
                    msg: ` error from sendEmail, Error: ${err.message}`,
                    status: "STRONG",
                    time: new Date().toUTCString(),
                    stack: err.stack
                };
                (0, errorReporting_1.LogError)(error_log);
                console.log({ err, action: "single without template error" });
            }
            break;
        case "bulk":
            try {
                feedback = yield controllers_1.BulkMailService.sendSingleEmailToMultiple(to, subject, text, html);
                console.log({ feedback, action: "bulk without template success" });
            }
            catch (err) {
                error_log = {
                    msg: ` error from sendEmail, Error: ${err.message}`,
                    status: "STRONG",
                    time: new Date().toUTCString(),
                    stack: err.stack
                };
                (0, errorReporting_1.LogError)(error_log);
                console.log({ err, action: "bulk without template error" });
            }
            break;
        case "single-template":
            try {
                feedback = yield controllers_1.SingleMailService.sendEmailWithTemplate(to, templateId, dynamicTemplateData);
                console.log({ feedback, action: "single with template success" });
            }
            catch (err) {
                error_log = {
                    msg: ` error from sendEmail, Error: ${err.message}`,
                    status: "STRONG",
                    time: new Date().toUTCString(),
                    stack: err.stack
                };
                (0, errorReporting_1.LogError)(error_log);
                console.log({ err, action: "single with template error" });
            }
            break;
        case "bulk-template":
            try {
                feedback = yield controllers_1.BulkMailService.sendSingleEmailToMultipleWithTemplate(to, templateId, dynamicTemplateData);
                console.log({ feedback, action: "bulk with template success" });
            }
            catch (err) {
                error_log = {
                    msg: ` error from sendEmail, Error: ${err.message}`,
                    status: "STRONG",
                    time: new Date().toUTCString(),
                    stack: err.stack
                };
                (0, errorReporting_1.LogError)(error_log);
                console.log({ err, action: "bulk with template error" });
            }
            break;
        case "bulk-multiple-template":
            try {
                feedback = yield controllers_1.BulkMailService.sendDifferentEmailToMultipleRecipientsWithTemplate(differentEmailTemplates);
                console.log({ feedback, action: "bulk multiple with template success" });
            }
            catch (err) {
                error_log = {
                    msg: ` error from sendEmail, Error: ${err.message}`,
                    status: "STRONG",
                    time: new Date().toUTCString(),
                    stack: err.stack
                };
                (0, errorReporting_1.LogError)(error_log);
                console.log({ err, action: "bulk multiple with template error" });
            }
            break;
        case "bulk-multiple":
            try {
                feedback = yield controllers_1.BulkMailService.sendDifferentEmailToMultipleRecipients(differentEmails);
                console.log({ feedback, action: "bulk multiple without template success" });
            }
            catch (err) {
                error_log = {
                    msg: ` error from sendEmail, Error: ${err.message}`,
                    status: "STRONG",
                    time: new Date().toUTCString(),
                    stack: err.stack
                };
                (0, errorReporting_1.LogError)(error_log);
                console.log({ err, action: "bulk multiple without template error" });
            }
            break;
        default:
            console.log({ action: "default" });
            break;
    }
});
exports.handler = handler;
/*
handler({detail: {type: "single",

data: {
    to: "soesitsocials@gmail.com",
    subject: "test",
    text: "test",
    html: "test"

}
}}, {} )
.then((res: any) => {
    console.log({res, action: "single without template success"})
    return res;
}
)
.catch((err: any) => {
    console.log({err, action: "single without template error"})
    return err;
}
);

 */
