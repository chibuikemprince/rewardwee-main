"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ENV = void 0;
exports.ENV = {
    PORT: 7002,
    DB: "mongodb://127.0.0.1:27017/email",
    DB_PRODUCTION: "mongodb://127.0.0.1:27017/email",
    SERVICE_NAME: "email",
    ENV: "development",
    GMAIL_SENDER_EMAIL: "rewardweetest@gmail.com",
    GMAIL_SENDER_PASSWORD: "rewardweetest@app223",
    SENDGRID_API_KEY: "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",
    SENDGRID_API_KEY_2: "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",
    SENDER_EMAIL: "youngprince042@gmail.com"
};
